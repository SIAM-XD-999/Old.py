# File-Cloning 

rm -rf File-Cloning

git clone https://github.com/Tutul-King/File-Cloning

cd File-Cloning

python Tutul.py
![orca-image-695895620](https://user-images.githubusercontent.com/106426526/231682454-f371fb63-6085-4b27-8ce2-abb220e4bc47.jpeg)
