import os 
import requests,bs4,json,os,sys,random,datetime,time,re

class Tutul:
    def __init__(self, z):
        for e in z + "\n":
            sys.stdout.write(e)
            sys.stdout.flush()
            time.sleep(0.040)
Tutul('\033[97;1m[\033[92;1m+\033[97;1m] \033[0;92mNEW UPDATE COMING SOON...? ')
time.sleep(5)
Tutul('\033[97;1m[\033[92;1m+\033[97;1m] \033[1;93mFOLLOW MY GROUP ')
os.system(f'xdg-open https://github.com/Tutul-King/')
time.sleep(7)
Tutul("\033[97;1m[\033[92;1m+\033[97;1m] \033[0;92mJOIN MY SCRIPT GIFT GROUP")
time.sleep(5)
os.system(f'xdg-open https://facebook.com/groups/554714119911648/')
Tutul("\033[97;1m[\033[92;1m+\033[97;1m] JOIN MESSENGER GROUP")
time.sleep(5)
os.system(f'xdg-open https://m.me/j/Aba78QeI-yhUqOwk/')